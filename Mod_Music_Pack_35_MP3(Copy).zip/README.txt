35 original instrumental sketches made for this pack.
They are newly composed synthetic tracks, not commercial songs or covers.
You may use and modify these tracks in your own Minecraft mod.
